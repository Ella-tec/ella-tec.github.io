export { default } from "next-auth/middleware";

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/portal/:path*",
    "/api/protected/:path*",
  ],
};
